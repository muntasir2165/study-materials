export { default } from "./FriendCard";
