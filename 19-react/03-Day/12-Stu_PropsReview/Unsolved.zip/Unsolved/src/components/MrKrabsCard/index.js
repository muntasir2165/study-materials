export { default } from "./MrKrabsCard";
