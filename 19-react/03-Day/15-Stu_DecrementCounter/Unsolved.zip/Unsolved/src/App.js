import React from "react";
import Counter from "./components/Counter";

const App = () => <Counter />;

export default App;
